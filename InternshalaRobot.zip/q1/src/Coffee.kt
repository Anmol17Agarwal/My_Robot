data class Coffee(var type: String, var cubeOfSuger: Int) {

}